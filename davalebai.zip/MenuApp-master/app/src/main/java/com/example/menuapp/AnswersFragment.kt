package com.example.menuapp

import androidx.fragment.app.Fragment

class AnswersFragment: Fragment(R.layout.answers_fragment) {
}