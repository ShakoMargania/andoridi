package com.example.menuapp

import androidx.fragment.app.Fragment

class HomeFragment: Fragment(R.layout.home_fragment) {
}